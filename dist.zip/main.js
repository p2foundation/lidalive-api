"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const common_1 = require("@nestjs/common");
const core_1 = require("@nestjs/core");
const helmet_1 = require("helmet");
const app_module_1 = require("./app.module");
const constants_1 = require("./constants");
async function bootstrap() {
    const logger = new common_1.Logger(bootstrap.name);
    const app = await core_1.NestFactory.create(app_module_1.AppModule);
    app.enableCors();
    app.use((0, helmet_1.default)());
    app.useGlobalPipes(new common_1.ValidationPipe());
    const port = process.env.PORT || constants_1.SERVER_PORT;
    await app.listen(port);
    logger.debug(`lidalive app server listening on PORT: ${port}`);
}
bootstrap();
//# sourceMappingURL=main.js.map