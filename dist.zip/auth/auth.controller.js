"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthController = void 0;
const common_1 = require("@nestjs/common");
const user_dto_1 = require("./dto/user.dto");
const auth_service_1 = require("./auth.service");
let AuthController = class AuthController {
    constructor(authService) {
        this.authService = authService;
        this.logger = new common_1.Logger('AuthController');
    }
    async loginUser(userData) {
        console.log(`signIn - incoming: ${JSON.stringify(userData)}`);
        const lu = await this.authService.login(userData);
        return lu;
    }
    async signUpUser(userData) {
        const su = await this.authService.signUp(userData);
        this.logger.log('registered users: ' + su);
        return su;
    }
    async getUserById(res, userId) {
        const gubi = await this.authService.getUserById(userId);
        res.status(common_1.HttpStatus.OK).json(gubi);
    }
    async findAllEmployees(res) {
        const fae = await this.authService.findAllEmployees();
        res.status(common_1.HttpStatus.OK).json(fae);
    }
    async getAllUsers(res) {
        const gau = await this.authService.getAllRegisteredUsers();
        res.status(common_1.HttpStatus.OK).json(gau);
    }
    async updateUserProfile(res, userId, changes) {
        console.log(`userProfile ${userId}: ${changes}`);
        const u2p = await this.authService.newMemberUpdate(userId, changes);
        res.status(common_1.HttpStatus.CREATED).send(u2p);
    }
    async deleteUserAccount(userId, res) {
        const dua = await this.authService.deleteUserAccount(userId);
        console.log(`user account with Id: ${userId} is successfully deleted`);
        console.log(`user account successfully deleted => ${dua} `);
        res.status(common_1.HttpStatus.CREATED).send(dua);
    }
    async deleteAllUserAccounts(res) {
        const daua = await this.authService.deleteAllUsers();
        res.status(common_1.HttpStatus.CREATED).send(daua);
    }
};
__decorate([
    (0, common_1.Post)('login'),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [user_dto_1.UserDto]),
    __metadata("design:returntype", Promise)
], AuthController.prototype, "loginUser", null);
__decorate([
    (0, common_1.Post)('signup'),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [user_dto_1.UserDto]),
    __metadata("design:returntype", Promise)
], AuthController.prototype, "signUpUser", null);
__decorate([
    (0, common_1.Get)('user/:userId'),
    __param(0, (0, common_1.Res)()),
    __param(1, (0, common_1.Param)('userId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", Promise)
], AuthController.prototype, "getUserById", null);
__decorate([
    (0, common_1.Get)('employees'),
    __param(0, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], AuthController.prototype, "findAllEmployees", null);
__decorate([
    (0, common_1.Get)('users'),
    __param(0, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], AuthController.prototype, "getAllUsers", null);
__decorate([
    (0, common_1.Put)('profile/:userId'),
    __param(0, (0, common_1.Res)()),
    __param(1, (0, common_1.Param)('userId')),
    __param(2, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, user_dto_1.UserDto]),
    __metadata("design:returntype", Promise)
], AuthController.prototype, "updateUserProfile", null);
__decorate([
    (0, common_1.Delete)('remove/:userId'),
    __param(0, (0, common_1.Param)('userId')),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], AuthController.prototype, "deleteUserAccount", null);
__decorate([
    (0, common_1.Delete)('/remove/all'),
    __param(0, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], AuthController.prototype, "deleteAllUserAccounts", null);
AuthController = __decorate([
    (0, common_1.Controller)('api/auth'),
    __metadata("design:paramtypes", [auth_service_1.AuthService])
], AuthController);
exports.AuthController = AuthController;
//# sourceMappingURL=auth.controller.js.map