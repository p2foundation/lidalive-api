import { Model } from 'mongoose';
import { PasswordHasherService } from './password.hasher.service';
import { JwtService } from '@nestjs/jwt';
import { UserDto } from './dto/user.dto';
import { UserInterface } from './interface/user.interface';
import { HttpService } from '@nestjs/axios';
export declare class AuthService {
    private readonly userModel;
    private passwordHaSherService;
    private jwtService;
    private httpService;
    private logger;
    constructor(userModel: Model<UserInterface>, passwordHaSherService: PasswordHasherService, jwtService: JwtService, httpService: HttpService);
    signUp(userData: Partial<UserDto>): Promise<UserInterface>;
    login(userData: UserDto): Promise<any>;
    getAllRegisteredUsers(): Promise<any>;
    getUserById(userId: string): Promise<UserInterface>;
    newMemberUpdate(userId: string, changes: Partial<UserDto>): Promise<UserInterface>;
    deleteUserAccount(userId: string): Promise<any>;
    deleteAllUsers(): Promise<any>;
    nextBirthDayWishList(): Promise<any>;
    birthDayOfMonth(): Promise<any>;
    findAllEmployees(): Promise<UserInterface[]>;
    validateUserById(userId: string): Promise<boolean>;
}
