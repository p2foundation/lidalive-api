export declare class CryptoService {
    private logger;
    generateSaltPassword(rawText: any): Promise<any>;
    randomStringGenerator(): Promise<any>;
}
