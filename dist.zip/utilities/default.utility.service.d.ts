export declare class DefaultUtilityService {
    private logger;
    private possible;
    private text;
    private date;
    private day;
    generateRandomMerchantKeys(): any;
    generateMerchantSecret(): any;
    generateReferenceNumber(): any;
}
