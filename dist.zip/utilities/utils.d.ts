export declare function generateMerchantKey(): string;
export declare function generateTransactionId(): string;
export declare function generateTransactionIdPayswitch(): string;
