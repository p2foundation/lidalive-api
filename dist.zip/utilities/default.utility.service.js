"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DefaultUtilityService = void 0;
const common_1 = require("@nestjs/common");
let DefaultUtilityService = class DefaultUtilityService {
    constructor() {
        this.logger = new common_1.Logger('DefaultUtilityService');
        this.possible = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        this.text = '';
        this.date = new Date();
        this.day = '';
    }
    generateRandomMerchantKeys() {
        this.day = (this.date.getDate() < 10 ? '0' : '') + this.date.getDate();
        const month = (this.date.getMonth() + 1 < 10 ? '0' : '') + (this.date.getMonth() + 1);
        const year = this.date.getFullYear().toString().substr(2, 2);
        const customDate = '' + month + this.day + year;
        for (let i = 0; i < 24; i++) {
            this.text += this.possible.charAt(Math.floor(Math.random() * this.possible.length));
        }
        const transId = this.text + customDate;
        this.logger.log('generated MerchantKey ++++ ' + transId);
        return transId;
    }
    generateMerchantSecret() {
        const day = (this.date.getDate() < 10 ? '0' : '') + this.date.getDate();
        const month = (this.date.getMonth() + 1 < 10 ? '0' : '') + (this.date.getMonth() + 1);
        const year = this.date.getFullYear().toString().substr(2, 2);
        const customDate = '' + month + day + year;
        for (let i = 0; i < 10; i++) {
            this.text += this.possible.charAt(Math.floor(Math.random() * this.possible.length));
        }
        const transId = this.text + customDate;
        this.logger.log('generated MerchantSecret --- ' + transId);
        return transId;
    }
    generateReferenceNumber() {
        this.day = (this.date.getDate() < 10 ? '0' : '') + this.date.getDate();
        const month = (this.date.getMonth() + 1 < 10 ? '0' : '') + (this.date.getMonth() + 1);
        const year = this.date.getFullYear().toString().substr(2, 2);
        const customDate = '' + month + this.day + year;
        for (let i = 0; i < 18; i++) {
            this.text += this.possible.charAt(Math.floor(Math.random() * this.possible.length));
        }
        const transId = this.text + customDate;
        this.logger.log('generated MerchantSecret --- ' + transId);
        return transId;
    }
};
DefaultUtilityService = __decorate([
    (0, common_1.Injectable)()
], DefaultUtilityService);
exports.DefaultUtilityService = DefaultUtilityService;
//# sourceMappingURL=default.utility.service.js.map