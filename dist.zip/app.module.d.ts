import { MiddlewareConsumer } from '@nestjs/common';
export declare class AppModule {
    configure(consumer: MiddlewareConsumer): void;
}
