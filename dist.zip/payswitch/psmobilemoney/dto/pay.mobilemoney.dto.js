"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PayMobileMoneyDto = void 0;
class PayMobileMoneyDto {
}
exports.PayMobileMoneyDto = PayMobileMoneyDto;
//# sourceMappingURL=pay.mobilemoney.dto.js.map