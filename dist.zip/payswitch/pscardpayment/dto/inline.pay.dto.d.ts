export declare class InlinePayDto {
    merchantId: string;
    transId: string;
    description: string;
    amount: any;
    redirectURL: string;
    customerEmail: string;
}
