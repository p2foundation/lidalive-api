"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CardPaymentDto = void 0;
class CardPaymentDto {
}
exports.CardPaymentDto = CardPaymentDto;
//# sourceMappingURL=card.payments.dto.js.map