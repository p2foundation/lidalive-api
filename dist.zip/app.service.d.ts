export declare class AppService {
    private readonly name;
    constructor(name: string);
    getHello(): string;
}
