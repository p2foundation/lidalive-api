import { AuthorizationGuard } from './authorization.guard';
export declare class AdminGuard extends AuthorizationGuard {
    constructor();
}
