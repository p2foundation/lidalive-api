"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SecurityDto = void 0;
class SecurityDto {
}
exports.SecurityDto = SecurityDto;
//# sourceMappingURL=security.dto.js.map