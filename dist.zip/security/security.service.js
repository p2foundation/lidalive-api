"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SecurityService = void 0;
const common_1 = require("@nestjs/common");
const jwt_1 = require("@nestjs/jwt");
const password_hasher_service_1 = require("./password.hasher.service");
const mongoose_1 = require("@nestjs/mongoose");
const mongoose_2 = require("mongoose");
const constants_1 = require("../constants");
const axios_1 = require("@nestjs/axios");
let SecurityService = class SecurityService {
    constructor(userModel, passwordHaSherService, jwtService, httpService) {
        this.userModel = userModel;
        this.passwordHaSherService = passwordHaSherService;
        this.jwtService = jwtService;
        this.httpService = httpService;
        this.logger = new common_1.Logger('SecurityService');
    }
    async userProfile(userId) {
        this.logger.debug(`userId: ${userId}`);
        return await this.userModel.findById(userId).exec();
    }
    async signUp(userData) {
        console.log(`register userData: ${JSON.stringify(userData)}`);
        const user = await this.userModel.findOne({
            $or: [{ email: userData.email }, { userName: userData.userName }],
        });
        if (user) {
            throw new common_1.UnauthorizedException(`User already created with this: ${userData.email}`);
        }
        const encryptedPassword = await this.passwordHaSherService.hashPassword(userData.password);
        const newUser = new this.userModel({
            userName: userData.userName,
            firstName: userData.firstName,
            lastName: userData.lastName,
            email: userData.email,
            mobile: userData.mobile,
            gravatar: userData.photo || userData.gravatar || '',
            status: userData.status,
            password: encryptedPassword,
        });
        try {
            this.logger.debug(`new user registered successfully ${newUser}`);
            return await newUser.save();
        }
        catch (e) {
            console.error(`error registering new user ==> ${e}`);
            throw new common_1.InternalServerErrorException();
        }
    }
    async login(userData) {
        console.log(`userData: ${JSON.stringify(userData)}`);
        const user = await this.userModel.findOne({
            $or: [{ email: userData.email }, { userName: userData.userName }],
        });
        console.log(`user found? ${user}`);
        if (!user) {
            throw new common_1.UnauthorizedException(`Invalid credentials ==> ${JSON.stringify(userData)}`);
        }
        const matchedPassword = await this.passwordHaSherService.comparePasswords(userData.password, user.password);
        if (matchedPassword) {
            const token = await this.jwtService.signAsync({ email: userData.email || userData.userName, id: user._id }, { expiresIn: constants_1.JWT_EXPIRE });
            this.logger.debug(`user successfully login (token) ==> ${token}`);
            return { token, user };
        }
        else {
            throw new common_1.UnauthorizedException(`Invalid password`);
        }
    }
    async validateUserById(userId) {
        const user = await this.userModel.findById(userId);
        if (user) {
            return true;
        }
        else {
            return false;
        }
    }
};
SecurityService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, mongoose_1.InjectModel)('Users')),
    __metadata("design:paramtypes", [mongoose_2.Model,
        password_hasher_service_1.PasswordHasherService,
        jwt_1.JwtService,
        axios_1.HttpService])
], SecurityService);
exports.SecurityService = SecurityService;
//# sourceMappingURL=security.service.js.map