import { JwtService } from '@nestjs/jwt';
import { PasswordHasherService } from './password.hasher.service';
import { Model } from 'mongoose';
import { SecurityInterface } from './interface/security.interface';
import { SecurityDto } from './dto/security.dto';
import { HttpService } from '@nestjs/axios';
export declare class SecurityService {
    private readonly userModel;
    private passwordHaSherService;
    private jwtService;
    private httpService;
    private logger;
    constructor(userModel: Model<SecurityInterface>, passwordHaSherService: PasswordHasherService, jwtService: JwtService, httpService: HttpService);
    userProfile(userId: string): Promise<any>;
    signUp(userData: SecurityInterface): Promise<SecurityInterface>;
    login(userData: SecurityDto): Promise<any>;
    validateUserById(userId: string): Promise<boolean>;
}
