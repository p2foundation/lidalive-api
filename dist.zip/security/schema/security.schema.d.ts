import * as mongoose from 'mongoose';
export declare const SecuritySchema: mongoose.Schema<any, mongoose.Model<any, any, any, any, any>, {}, {}, {}, {}, mongoose.DefaultSchemaOptions, {
    status: string;
    role: "GUEST" | "USER" | "ADMIN" | "DEVELOPER";
    createdAt: Date;
    updatedAt: Date;
    userName?: string;
    firstName?: string;
    lastName?: string;
    email?: string;
    mobile?: string;
    password?: string;
    gravatar?: string;
}>;
