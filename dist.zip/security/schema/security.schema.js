"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SecuritySchema = void 0;
const mongoose = require("mongoose");
exports.SecuritySchema = new mongoose.Schema({
    userName: String,
    firstName: String,
    lastName: String,
    email: String,
    mobile: String,
    gravatar: String,
    role: {
        enum: ['GUEST', 'USER', 'ADMIN', 'DEVELOPER'],
        type: String,
        default: 'USER',
    },
    status: { type: String, default: 'ACTIVE' },
    password: String,
    createdAt: { type: Date, default: Date.now() },
    updatedAt: { type: Date, default: Date.now() },
});
//# sourceMappingURL=security.schema.js.map