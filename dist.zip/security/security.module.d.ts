export declare class SecurityModule {
}
