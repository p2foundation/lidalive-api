import { SecurityService } from './security.service';
import { SecurityDto } from './dto/security.dto';
import { SecurityInterface } from './interface/security.interface';
export declare class SecurityController {
    private readonly authService;
    private logger;
    constructor(authService: SecurityService);
    login(userData: SecurityDto): Promise<SecurityDto>;
    signUp(userData: SecurityInterface): Promise<any>;
    profile(userId: string): Promise<any>;
}
