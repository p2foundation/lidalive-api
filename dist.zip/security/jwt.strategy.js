"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.JwtStrategy = void 0;
const passport_1 = require("@nestjs/passport");
const passport_jwt_1 = require("passport-jwt");
const constants_1 = require("../constants");
const common_1 = require("@nestjs/common");
class JwtStrategy extends (0, passport_1.PassportStrategy)(passport_jwt_1.Strategy) {
    constructor(authService) {
        super({
            jwtFromRequest: passport_jwt_1.ExtractJwt.fromAuthHeaderAsBearerToken(),
            ignoreExpiration: false,
            secretOrKey: process.env.JWT_SECRET || constants_1.JWT_SECRET,
        });
        this.authService = authService;
    }
    async validate(payload) {
        const isValidated = await this.authService.validateUserById(payload.id);
        if (isValidated) {
            return { userId: payload.id, email: payload.email };
        }
        else {
            throw new common_1.UnauthorizedException('UnAuthorized');
        }
    }
}
exports.JwtStrategy = JwtStrategy;
//# sourceMappingURL=jwt.strategy.js.map