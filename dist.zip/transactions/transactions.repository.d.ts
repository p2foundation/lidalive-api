import { Model } from 'mongoose';
import { TransactionDto } from './dto/transaction.dto';
import { TransactionInterface } from './interface/transaction.interface';
export declare class TransactionsRepository {
    private readonly transactionModel;
    private logger;
    constructor(transactionModel: Model<TransactionInterface>);
    findAllTransactions(): Promise<TransactionInterface[]>;
    findTransById(transId: string): Promise<TransactionInterface>;
    saveTransaction(userId: string, merchantId: string, transData: any): Promise<TransactionInterface>;
    updateTransactionRecord(transId: string, changes: TransactionDto): Promise<TransactionInterface>;
    removeTransRecord(transId: string): Promise<any>;
}
