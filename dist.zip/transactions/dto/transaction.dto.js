"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TransactionDto = void 0;
class TransactionDto {
}
exports.TransactionDto = TransactionDto;
//# sourceMappingURL=transaction.dto.js.map