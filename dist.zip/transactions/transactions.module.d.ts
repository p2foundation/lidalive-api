export declare class TransactionsModule {
}
