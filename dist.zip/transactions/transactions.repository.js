"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var TransactionsRepository_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.TransactionsRepository = void 0;
const common_1 = require("@nestjs/common");
const mongoose_1 = require("@nestjs/mongoose");
const mongoose_2 = require("mongoose");
let TransactionsRepository = TransactionsRepository_1 = class TransactionsRepository {
    constructor(transactionModel) {
        this.transactionModel = transactionModel;
        this.logger = new common_1.Logger(TransactionsRepository_1.name);
    }
    async findAllTransactions() {
        const allTrans = await this.transactionModel.find().exec();
        return allTrans;
    }
    async findTransById(transId) {
        const ftbi = await this.transactionModel.findById({ _id: transId }).exec();
        return ftbi;
    }
    async saveTransaction(userId, merchantId, transData) {
        const payload = {
            clientId: transData.clientId,
            clientSecret: transData.clientSecret,
            retailer: transData.retailer,
            customerMsisdn: transData.customerMsisdn,
            channel: transData.channel,
            amount: transData.amount,
            primaryCallbackUrl: transData.primaryCallbackUrl,
            clientReference: transData.clientReference,
            description: transData.description,
            merchantName: transData.merchantName,
            transType: transData.transType,
            serviceName: transData.serviceName,
            customerName: transData.customerName,
            customerEmail: transData.customerEmail,
            merchantReference: transData.merchantReference,
            localTransId: transData.transId,
            originalAmount: transData.originalAmount,
            amountPaid: transData.amountPaid,
            charge: transData.charge,
            network: transData.network,
            recipientNumber: transData.recipientNumber,
            senderNumber: transData.senderNumber,
            product: transData.product,
            transDescription: transData.transDescription,
            vouche: transData.voucher || transData.token,
            serviceStatus: transData.serviceName,
            transMessage: transData.transMessage,
            serviceTransId: transData.serviceTransId,
            transStatus: transData.transStatus,
            paymentStatus: transData.paymentStatus,
            callbackReceipt: transData.callbackReceipt,
            commentary: transData.commentary,
            callbackUrl: transData.callbackUrl,
            price: transData.price,
            recipient_number: transData.recipient_number,
            sender: transData.sender,
            award: transData.award,
            orderID: transData.orderID,
            token: transData.token,
            currentBalance: transData.currentBalance,
            balanceAfter: transData.balanceAfter,
            balanceBefore: transData.balanceBefore,
        };
        const newTrans = new this.transactionModel(payload);
        try {
            await newTrans.save();
            this.logger.log('Transaction saved successfully');
        }
        catch (e) {
            this.logger.error(`ERROR SAVING TRANSACTION: ${JSON.stringify(e)}`);
        }
        return newTrans;
    }
    async updateTransactionRecord(transId, changes) {
        const utr = await this.transactionModel.findByIdAndUpdate(transId, changes, {
            new: true,
        });
        return utr;
    }
    async removeTransRecord(transId) {
        const rtr = await this.transactionModel.findByIdAndRemove(transId);
        return rtr;
    }
};
TransactionsRepository = TransactionsRepository_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, mongoose_1.InjectModel)('Transaction')),
    __metadata("design:paramtypes", [mongoose_2.Model])
], TransactionsRepository);
exports.TransactionsRepository = TransactionsRepository;
//# sourceMappingURL=transactions.repository.js.map