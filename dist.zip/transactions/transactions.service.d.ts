import { HttpService } from '@nestjs/axios';
export declare class TransactionsService {
    private readonly httpService;
    private logger;
    constructor(httpService: HttpService);
}
