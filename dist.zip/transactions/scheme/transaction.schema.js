"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TransactionSchema = void 0;
const mongoose = require("mongoose");
exports.TransactionSchema = new mongoose.Schema({
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'Users' },
    merchantId: { type: mongoose.Schema.Types.ObjectId, ref: 'Merchants' },
    merchantName: String,
    transType: String,
    serviceName: String,
    customerName: String,
    customerEmail: String,
    MerchantReference: String,
    retailer: String,
    localTransId: String,
    originalAmount: String,
    amountPaid: String,
    charge: String,
    network: String,
    recipientNumber: String,
    senderNumber: String,
    transDescription: String,
    voucher: String,
    serviceCode: String,
    transMessage: String,
    serviceTransId: String,
    transStatus: String,
    paymentStatus: String,
    callbackUrl: String,
    callbackReceipt: String,
    currentBalance: String,
    balanceBefore: String,
    balanceAfter: String,
    award: String,
    commentary: String,
});
//# sourceMappingURL=transaction.schema.js.map