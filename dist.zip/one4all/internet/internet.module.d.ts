export declare class InternetModule {
}
