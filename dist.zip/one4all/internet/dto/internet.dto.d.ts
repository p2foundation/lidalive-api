export declare class InternetDto {
    readonly retailer: string;
    recipientNumber: string;
    dataCode?: string;
    network: number;
    transId: string;
}
