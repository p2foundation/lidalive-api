"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.InternetDto = void 0;
class InternetDto {
}
exports.InternetDto = InternetDto;
//# sourceMappingURL=internet.dto.js.map