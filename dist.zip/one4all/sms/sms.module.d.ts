export declare class SmsModule {
}
