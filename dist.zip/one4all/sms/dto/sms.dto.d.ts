export declare class SmsDto {
    recipient: number;
    message: string;
    senderId: string;
    clientReference: string;
}
