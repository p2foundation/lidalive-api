"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SmsDto = void 0;
class SmsDto {
}
exports.SmsDto = SmsDto;
//# sourceMappingURL=sms.dto.js.map