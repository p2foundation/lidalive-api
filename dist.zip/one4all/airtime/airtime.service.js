"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AirtimeService = void 0;
const axios_1 = require("@nestjs/axios");
const common_1 = require("@nestjs/common");
const operators_1 = require("rxjs/operators");
const https = require("https");
const constants_1 = require("../../constants");
const utils_1 = require("../../utilities/utils");
const transactions_repository_1 = require("../../transactions/transactions.repository");
let AirtimeService = class AirtimeService {
    constructor(httpService, transactionRepo) {
        this.httpService = httpService;
        this.transactionRepo = transactionRepo;
        this.logger = new common_1.Logger('AirtimeService');
        this.AirBaseUrl = constants_1.ONE4ALL_BASEURL;
    }
    transactionStatus(transDto) {
        const { transReference } = transDto;
        const payload = {
            trnx: transReference || '',
        };
        const tsUrl = this.AirBaseUrl + `/TopUpApi/transactionStatus?trnx=${payload.trnx}`;
        const configs = {
            url: tsUrl,
            headers: { ApiKey: constants_1.ONE4ALL_APIKEY, ApiSecret: constants_1.ONE4ALL_APISECRET },
            agent: new https.Agent({
                rejectUnauthorized: false,
            }),
        };
        this.logger.log(`transaction status payload == ${JSON.stringify(configs)}`);
        return this.httpService
            .get(configs.url, { httpsAgent: configs.agent, headers: configs.headers })
            .pipe((0, operators_1.map)((tsRes) => {
            this.logger.log(`Query TRANSACTION STATUS response ++++ ${JSON.stringify(tsRes.data)}`);
            return tsRes.data;
        }), (0, operators_1.catchError)((tsError) => {
            this.logger.error(`Query TRANSACTION STATUS ERROR response ---- ${JSON.stringify(tsError.response.data)}`);
            const tsErrorMessage = tsError.response.data;
            throw new common_1.NotFoundException(tsErrorMessage);
        }));
    }
    topupAirtimeService(transDto) {
        const { retailer, recipientNumber, amount, network, userId, merchantId } = transDto;
        const taParams = {
            userId: userId,
            merchantId: merchantId,
            transType: 'AIRTIME TOPUP',
            retailer: constants_1.ONE4ALL_RETAILER || retailer,
            network: 0 || network,
            recipient: recipientNumber || '',
            amount: amount || '',
            trxn: (0, utils_1.generateTransactionId)() || '',
            originalAmount: '',
            fee: 0,
            recipientNumber: recipientNumber || '',
            serviceCode: '',
            transMessage: '',
            serviceTransId: '',
            transStatus: '',
            commentary: '',
            balance_before: '',
            balance_after: '',
            currentBalance: '',
        };
        this.logger.log(`AIRTIME TOPUP params == ${JSON.stringify(taParams)}`);
        const taUrl = `/TopUpApi/airtime?retailer=${taParams.retailer}&recipient=${taParams.recipient}&amount=${taParams.amount}&network=${taParams.network}&trxn=${taParams.trxn}`;
        const configs = {
            url: this.AirBaseUrl + taUrl,
            headers: { ApiKey: constants_1.ONE4ALL_APIKEY, ApiSecret: constants_1.ONE4ALL_APISECRET },
            agent: new https.Agent({
                rejectUnauthorized: false,
            }),
        };
        this.logger.log(`Airtime topup payload == ${JSON.stringify(configs)}`);
        return this.httpService
            .get(configs.url, {
            httpsAgent: configs.agent,
            headers: configs.headers,
        })
            .pipe((0, operators_1.map)((taRes) => {
            this.logger.verbose(`AIRTIME TOPUP response ++++ ${JSON.stringify(taRes.data)}`);
            if (taRes.data.status_code === '02') {
                this.logger.warn(`insufficient balance`);
                taParams.serviceCode = '';
                taParams.transMessage = '';
                taParams.serviceTransId = '';
                taParams.transStatus = '';
                taParams.commentary = '';
            }
            else if (taRes.data.status_code === '09') {
                this.logger.warn(`recharge requested but awaiting status`);
                taParams.serviceCode = '';
                taParams.transMessage = '';
                taParams.serviceTransId = '';
                taParams.transStatus = '';
                taParams.commentary = '';
            }
            else if (taRes.data.status_code === '06') {
                this.logger.log(`other error message`);
                taParams.serviceCode = '';
                taParams.transMessage = '';
                taParams.serviceTransId = '';
                taParams.transStatus = '';
                taParams.commentary = '';
            }
            else if (taRes.data.status_code === '00') {
                this.logger.verbose(`airtime topup successful`);
                taParams.serviceCode = taRes.data['status-code'];
                taParams.transMessage = taRes.data.message;
                taParams.serviceTransId = taRes.data.trxn;
                taParams.transStatus = taRes.data.status;
                taParams.balance_before = taRes.data.balance_before;
                taParams.balance_after = taRes.data.balance_after;
                taParams.commentary = `Airtime top-up for ${recipientNumber} successful`;
            }
            return taRes.data;
        }), (0, operators_1.catchError)((taError) => {
            this.logger.error(`AIRTIME TOP-UP ERROR response --- ${JSON.stringify(taError.response.data)}`);
            const taErrorMessage = taError.response.data;
            throw new common_1.NotFoundException(taErrorMessage);
        }));
    }
};
AirtimeService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [axios_1.HttpService,
        transactions_repository_1.TransactionsRepository])
], AirtimeService);
exports.AirtimeService = AirtimeService;
//# sourceMappingURL=airtime.service.js.map