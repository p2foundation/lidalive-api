"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AppModule = void 0;
const common_1 = require("@nestjs/common");
const mongoose_1 = require("@nestjs/mongoose");
const app_controller_1 = require("./app.controller");
const app_service_1 = require("./app.service");
const auth_module_1 = require("./auth/auth.module");
const constants_1 = require("./constants");
const merchants_controller_1 = require("./merchants/merchants.controller");
const merchants_module_1 = require("./merchants/merchants.module");
const getuser_middleware_1 = require("./middleware/getuser.middleware");
const airtime_module_1 = require("./one4all/airtime/airtime.module");
const internet_module_1 = require("./one4all/internet/internet.module");
const mobilemoney_module_1 = require("./one4all/mobilemoney/mobilemoney.module");
const sms_module_1 = require("./one4all/sms/sms.module");
const pscardpayment_module_1 = require("./payswitch/pscardpayment/pscardpayment.module");
const psmobilemoney_module_1 = require("./payswitch/psmobilemoney/psmobilemoney.module");
const security_module_1 = require("./security/security.module");
const transactions_module_1 = require("./transactions/transactions.module");
let AppModule = class AppModule {
    configure(consumer) {
        consumer.apply(getuser_middleware_1.GetUserMiddleware).forRoutes(merchants_controller_1.MerchantsController);
    }
};
AppModule = __decorate([
    (0, common_1.Module)({
        imports: [
            auth_module_1.AuthModule,
            security_module_1.SecurityModule,
            mongoose_1.MongooseModule.forRoot(process.env.MONGODB_URI || constants_1.MONGODB_URI),
            merchants_module_1.MerchantsModule,
            airtime_module_1.AirtimeModule,
            internet_module_1.InternetModule,
            mobilemoney_module_1.MobilemoneyModule,
            sms_module_1.SmsModule,
            pscardpayment_module_1.PscardpaymentModule,
            psmobilemoney_module_1.PsmobilemoneyModule,
            transactions_module_1.TransactionsModule,
        ],
        controllers: [app_controller_1.AppController],
        providers: [
            {
                provide: app_service_1.AppService,
                useClass: app_service_1.AppService,
            },
            {
                provide: 'APP_NAME',
                useValue: 'LidaPay BACKEND',
            },
        ],
    })
], AppModule);
exports.AppModule = AppModule;
//# sourceMappingURL=app.module.js.map