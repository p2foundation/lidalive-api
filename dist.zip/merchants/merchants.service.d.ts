import { MerchantsInterface } from './interface/merchants.interface';
import { Model } from 'mongoose';
import { SecurityInterface } from '../security/interface/security.interface';
import { CryptoService } from 'src/utilities/crypto.service';
import { DefaultUtilityService } from 'src/utilities/default.utility.service';
export declare class MerchantsService {
    private readonly merchantsModel;
    private cryptoService;
    private defaultUtilityService;
    private logger;
    constructor(merchantsModel: Model<MerchantsInterface>, cryptoService: CryptoService, defaultUtilityService: DefaultUtilityService);
    getRegisteredMerchants(): Promise<any>;
    findMerchantById(merchantId: string): Promise<any>;
    registerNewMerchant(userId: SecurityInterface, merchantsData: MerchantsInterface): Promise<MerchantsInterface>;
    updateMerchantRecord(merchantId: string, changes: MerchantsInterface): Promise<MerchantsInterface>;
    confirmMerchantAccount(merchantId: string, change: MerchantsInterface): Promise<any>;
    deActivateMerchantAccount(merchantId: string, change: MerchantsInterface): Promise<any>;
    deleteMerchantAccount(merchantId: string): Promise<any>;
}
