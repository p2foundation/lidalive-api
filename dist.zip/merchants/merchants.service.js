"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MerchantsService = void 0;
const common_1 = require("@nestjs/common");
const mongoose_1 = require("@nestjs/mongoose");
const mongoose_2 = require("mongoose");
const crypto_service_1 = require("../utilities/crypto.service");
const default_utility_service_1 = require("../utilities/default.utility.service");
let MerchantsService = class MerchantsService {
    constructor(merchantsModel, cryptoService, defaultUtilityService) {
        this.merchantsModel = merchantsModel;
        this.cryptoService = cryptoService;
        this.defaultUtilityService = defaultUtilityService;
        this.logger = new common_1.Logger('MerchantsService');
    }
    async getRegisteredMerchants() {
        const grm = await this.merchantsModel.find().exec();
        const totalCount = await this.merchantsModel.countDocuments();
        return { grm, totalCount };
    }
    async findMerchantById(merchantId) {
        return this.merchantsModel.findById({ _id: merchantId });
    }
    async registerNewMerchant(userId, merchantsData) {
        const merchant = await this.merchantsModel.findOne({
            $or: [{ email: merchantsData.email }, { userName: merchantsData.mobile }],
        });
        if (merchant) {
            throw new common_1.UnauthorizedException(`Merchant already registered with this: ${merchantsData.email}`);
        }
        const { clientName, clientDescription, websiteUrl, email, mobile, address, } = merchantsData;
        const secret = this.defaultUtilityService.generateMerchantSecret();
        const key = this.defaultUtilityService.generateRandomMerchantKeys();
        const payload = {
            userId: userId,
            clientName: clientName,
            clientSecret: secret,
            apiKey: key,
            clientDescription: clientDescription,
            websiteUrl: websiteUrl,
            email: email,
            mobile: mobile,
            address: address,
        };
        const newMerchants = await new this.merchantsModel(payload);
        try {
            await newMerchants.save();
        }
        catch (e) {
            this.logger.error(`error save new merchant${e}`);
        }
        return newMerchants;
    }
    async updateMerchantRecord(merchantId, changes) {
        const um = await this.merchantsModel.findOneAndUpdate({ _id: merchantId }, changes, { new: true });
        return um;
    }
    async confirmMerchantAccount(merchantId, change) {
        return this.merchantsModel.findOneAndUpdate({ _id: merchantId }, change, {
            new: true,
        });
    }
    async deActivateMerchantAccount(merchantId, change) {
        return this.merchantsModel.findOneAndUpdate({ _id: merchantId }, change, {
            new: true,
        });
    }
    async deleteMerchantAccount(merchantId) {
        this.logger.log(`merchantId: ${merchantId}`);
        return this.merchantsModel.findByIdAndDelete({ _id: merchantId });
    }
};
MerchantsService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, mongoose_1.InjectModel)('Merchants')),
    __metadata("design:paramtypes", [mongoose_2.Model,
        crypto_service_1.CryptoService,
        default_utility_service_1.DefaultUtilityService])
], MerchantsService);
exports.MerchantsService = MerchantsService;
//# sourceMappingURL=merchants.service.js.map