import * as mongoose from 'mongoose';
export declare const MerchantsSchema: mongoose.Schema<any, mongoose.Model<any, any, any, any, any>, {}, {}, {}, {}, mongoose.DefaultSchemaOptions, {
    status: string;
    createdAt: Date;
    updatedAt: Date;
    isConfirmed: boolean;
    email?: string;
    mobile?: string;
    userId?: mongoose.Types.ObjectId;
    apiKey?: string;
    clientName?: string;
    clientSecret?: string;
    websiteUrl?: string;
    address?: string;
    ClientDescription?: string;
}>;
