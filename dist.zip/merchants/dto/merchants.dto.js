"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MerchantsDto = void 0;
class MerchantsDto {
}
exports.MerchantsDto = MerchantsDto;
//# sourceMappingURL=merchants.dto.js.map