import { MerchantsInterface } from './interface/merchants.interface';
import { Response } from 'express';
import { MerchantsService } from './merchants.service';
import { SecurityInterface } from '../security/interface/security.interface';
export declare class MerchantsController {
    private merchantsService;
    private logger;
    constructor(merchantsService: MerchantsService);
    findAllRegisteredMerchants(res: Response): Promise<any>;
    saveNewMerchant(res: Response, userId: SecurityInterface, merchantData: MerchantsInterface): Promise<any>;
    updateMerchantRecord(res: Response, merchantId: string, changes: MerchantsInterface): Promise<any>;
    removeMerchant(res: Response, merchantId: string): Promise<any>;
}
